import React, { useRef } from "react";
import HTMLFlipBook from "react-pageflip";

function Products(props) {
  const bookRef = useRef();

  // حواست باشه به خاطر برعکس کردن کتاب لاجیک دکمه بعدی و قبلی هم برعکس شده

  const goToNextPage = () => {
    if (bookRef.current) {
      bookRef.current.pageFlip().flipPrev();
    }
  };

  const goToPrevPage = () => {
    if (bookRef.current) {
      bookRef.current.pageFlip().flipNext();
    }
  };
  const closeBook = () => {
    if (bookRef.current) {
      // bookRef.current.pageFlip().flipClose();
      props.setStatus(false)
    }
  }
  const pages = {
    "Books": [
      {
        "slides": [
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-2.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-2.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-3.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-3.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-4.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-4.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-5.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-5.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-6.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-6.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-7.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-7.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-8.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-8.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-9.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-9.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-10.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-10.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-11.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-11.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-12.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-12.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-13.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-13.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-14.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-14.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-15.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-15.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-16.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-16.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-17.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-17.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-18.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-18.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-19.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-19.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-20.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-20.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-21.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-21.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-22.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-22.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-23.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-23.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-24.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-24.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-25.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-25.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-26.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-26.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-27.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-27.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-28.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-28.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-29.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-29.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-30.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-30.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-31.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-31.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-32.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-32.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-33.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-33.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-34.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-34.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-35.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-35.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-36.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-36.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-37.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-37.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-38.jpg",
          "https://ostan-mr.ir/uploads/books/rahavard/rahavard-38.jpg",
        ],
        "_id": "66c3055ef1466acf04731b76",
        "title": "رهاورد خدمت",
        "created_at": "2024-08-13T08:58:33.656Z",
        "updated_at": "2024-08-13T08:58:33.656Z",
        "__v": 0,
        "url": "https://ostan-mr.ir/uploads/books/tumb.jpg",
        "id": "66c3055ef1466acf04731b76"
      }
    ]
  }
  console.log('pages',pages.Books[0].slides.length);
  const showReverse = pages.Books[0].slides.reverse()
  // const val = showReverse.unshift('')
  console.log('val',showReverse);
  
  const totalPages = pages.Books[0].slides.length;

  return (
    <div
      dir="rtl"
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        direction: "rtl",
        position: "absolute",
      }}>
      <HTMLFlipBook
        startZIndex={2}
        ref={bookRef}
        width={400}
        height={500}
        showCover={true} // showCover should be a boolean, not a string
        startPage={totalPages - 1}>
       
          { pages.Books[0].slides.map((item, index) => (
            <div className="demoPage" key={index}>
        
           <div className="page-image" style={{ backgroundImage: `url(${item})` }}>
   
           </div>
          
    
                 {/* <img
            src={item}
            alt="..."
            className="img-fluid"
            style={{
              height: "100%",
              width: "100%",
            }}
          /> */}
        </div>

          ))}
        {/* <div className="demoPage">
          <img
            src="https://ostan-mr.ir/uploads/books/rahavard/rahavard-112.jpg"
            alt="..."
            className="img-fluid"
            style={{
              height: "100%",
              width: "100%",
            }}
          />
        </div>
        <div className="demoPage">
          <img
            src="https://ostan-mr.ir/uploads/books/rahavard/rahavard-95.jpg"
            alt="..."
            className="img-fluid"
            style={{
              height: "100%",
              width: "100%",
            }}
          />
        </div>
        <div className="demoPage">
          <img
            src="https://ostan-mr.ir/uploads/books/rahavard/rahavard-96.jpg"
            alt="..."
            className="img-fluid"
            style={{
              height: "100%",
              width: "100%",
            }}
          />
        </div>
        <div className="demoPage">
          <img
            src="https://ostan-mr.ir/uploads/books/rahavard/rahavard-95.jpg"
            alt="..."
            className="img-fluid"
            style={{
              height: "100%",
              width: "100%",
            }}
          />
        </div>

        <div className="demoPage">
          <img
            src="https://ostan-mr.ir/uploads/books/tumb.jpg"
            alt="..."
            className="img-fluid"
            style={{
              height: "100%",
              width: "100%",
            }}
          />
        </div> */}
      </HTMLFlipBook>

      {/* <div
      className="control"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "10px",
          marginTop: "10px",
          zIndex: "10000"
        }}>
<div
    style={{
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "30px"
    }}>
      <svg
      onClick={goToPrevPage}
      width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M14.43 5.92993L20.5 11.9999L14.43 18.0699" stroke="#292D32" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M3.5 12H20.33" stroke="#292D32" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>


<svg
className="nextBtn"
   onClick={goToNextPage}
      width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M14.43 5.92993L20.5 11.9999L14.43 18.0699" stroke="#292D32" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M3.5 12H20.33" stroke="#292D32" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

    

</div>

<svg
onClick={closeBook}
width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12 22C17.5 22 22 17.5 22 12C22 6.5 17.5 2 12 2C6.5 2 2 6.5 2 12C2 17.5 6.5 22 12 22Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M9.16998 14.8299L14.83 9.16992" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M14.83 14.8299L9.16998 9.16992" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

      </div> */}

    </div>
  );
}

export default Products;
